/***** begin user configuration section *****/

#undef HAVE_NCURSES_H

#undef HAVE_CURSES_H

#undef NO_SYSERRL

#undef NEED_PUTC_CHAR

#undef HAVE_NCURSES_TERM_H 
